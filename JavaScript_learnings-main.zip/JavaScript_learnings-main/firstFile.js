//First Program:
// console.log("Hello World")

/*
basic of Data Types:
2 types

1)Primitive type
Number, String, Boolean, null, Symbol, Undefined

2) Non Primitive type
Object, Arrays
*/

/* 1)Numbers : Integers are limited by ±(253-1).*/
// there is bigit for arbitrary length.
// let n = 10;
// console.log(n);//integer
// n = 10.002;
// console.log(n);//floating

// console.log(1 / 0);
// console.log(0 / 1);
// console.log(Infinity);

// NaN stands for Not a Number.
// all of the below consoles prints NaN
// console.log(NaN + 1);
// console.log(NaN + NaN); 
// console.log(NaN * 5);
// console.log(NaN * NaN);

// console.log(NaN ** 0);//this prints 0

// let newName = "John";
// console.log(newName);

// 2) Strings: A string may have zero or more characters, there’s no separate single-character type.
// string values should be enclosed with single('') or double("") quotes. Strings can also be assigned in backticks using $ charecter : ${...}
// newName = "Ameer";
// console.log(newName);
// console.log(typeof (newName));

/* 3) Boolean : it is used for condition checks and displays true/false */
// let a = 4 != 5;
// let isGreater = 0 > 1;
// console.log(isGreater);
// console.log(typeof (isGreater));
// console.log(a);
// console.log(typeof (a));


/* 4) null : It is a standalone type that has a single value null*/
// let x = null;
// console.log(x);//here the x value is null as declared
// console.log(typeof (x)); // and its type of returns object

/* 5) Undefined : it is used for unassigned values.
// let myName; // here the variable is only declared not initialized.
// console.log(myName); //returns undefined
// console.log(typeof (myName)); // returns undefined

// myName = 'Ameer';//now assigning a values to the variable myName.
// console.log(myName);
// console.log(typeof (myName));

// myName = undefined;//now assigning the values as undefined to the variable myName.
// console.log(myName);// returns undefined
// console.log(typeof (myName));// returns undefined
*/

/* 6) Symbol
The symbol type is used to create unique identifiers for objects.
*/

//Non-Primitive Data Type:
/* Object is a non-primitive Data Type in js. It is used to store collections of data and more complex entities.*/


// Typeof operator gives the following results of different types. //Syntax : typeof(variable);
// typeof undefined // "undefined"
// typeof 0 // "number"
// console.log(typeof (10n)) "bigint"
// typeof true // "boolean"
// typeof "foo" // "string"
// typeof Symbol("id") // "symbol"
// typeof Math // "object"  (1)
// typeof null // "object"  (2)
// typeof alert // "function"  (3)

//Exercise:


// We covered 3 browser-specific functions to interact with visitors: alert, prompt and confirm.

// alert
// shows a message.
// alert('text')

// prompt
// shows a message asking the user to input text. It returns the text or, if Cancel button or Esc is clicked, null.
// varable = prompt(title, [default]); // here the default field is optional, [..] square brackets denotes optional.

// confirm
// shows a message and waits for the user to press “OK” or “Cancel”. It returns true for OK and false for Cancel/Esc.
// varable = confirm(question);

// Type Convertion
