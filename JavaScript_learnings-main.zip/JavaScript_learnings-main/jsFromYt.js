//==>Operators in JavaScript

// const { useContext } = require("react/cjs/react.production.min")


// Arithmetic Operators:

// + Addition,
// - Subtraction,
// / Division, 
// * Multiplication ,
// % Modular Division, 
// ** Exponential Division 
// ++ Increment: Prefix and Postfix
// -- Decrement: Prefix and Postfix

// let num = 5;
// console.log(num++);

// In Prefix Incr / Decr the increment or decrement is done before operation
// In Postfix Incr / Decr the increment or decrement is done after operation

// Comparison Operator:
// == Equals to
// != Equals to
// > Greater than
// < Less than
// >= Greater than or equal
// <= less than or equal
// REturns Boolean values

// ==> Logical Operators:
// && Logical AND Operator //RETURNS TRUE IF ALL OF ITS EXPRESSIONS ARE TRUE ELSE RETURNS FALSE
// || LOgiacal OR Operator  //RETURNS TRUE IF ANY OF ITS EXPRESSION IS TRUE ELSE RETURNS FALSE
// ! Logical Not Operator // returns the oppposite of the value : if true returns false and vise versa

// let a = 2, b = 5, c = 10;

// console.log((a < b) && (a > c) && (b > c)); //returns false as one value is false

// console.log((a < b) || (a > c) || (b > c)); //returns true as one value is true

// console.log((a < b));
// console.log(!(a < b));


// ==> String operator: concatination operator (+)
// console.log("Hello " + "world") // returns Hello World

// let name = 'Hamza';
// console.log('Ameer ' + name); 

// Exersice:
// console.log(4 ** 2);

// console.log(5 + "Hello");

// Swapping of two numbers
// let a = 10, b = 20, temp;
// temp = a;
// a = b;
// b = temp;
// console.log(a, b);

// Swappping two numbers without 3rd variable 
// let a = 10, b = 5;
// a = a + b;// a=15
// b = a - b;//b=10
// a = a - b;//a=5
// console.log(a, b)//returns value of a=5, and b=10
// let a = 8;
// for (let x = 1; x <= 10; x++) {
//     console.log(a + '*' + x + '=' + (a * x));
// }



// ===>Functions:
//Function is a reusable code which is defined once and used many times.

//syntax:
// function function_name(){
//     // statements goes here.
// }

// let a = 10; b = 20;
// function sum(a, b) {
//     console.log(a + b);
// }
// sum(a, b);
// sum(40, 20);
// sum(19.5, 0.5);
// sum('a', 'b');

// function sum(a, b) {
//     return (a + b);
// }
// let add = sum(10, 20);
// console.log(add);

// Ananymous function:
// let sum = function (a, b) {
//     return (a + b);
// }
// console.log(sum(10, 20));


//==> Control Statements:
// If...else Statements:

// let a = 20;
// if (a < 10) {
//     console.log("a is less than 10");
// } else {
//     console.log("a is greater than 10");
// }

// Example for nested if-else statements:
// let year = 2022;
// debugger
// if (year % 4 == 0) {
//     if (year % 100 == 0) {
//         if (year % 400 == 0) {
//             console.log("this is a leap year");
//         } else {
//             console.log("this is not a leap year");
//         }
//     }
//     else {
//         console.log("this is a leap year");
//     }
// } else {
//     console.log("this is not a leap year");
// }

//Switch Statements:
// let area = 'square';
// let b = 10, h = 10, s = 5, ln = 10, br = 5, r = 3;
// switch (area) {
//     case 'rectangle': console.log(`area of rectangle is ${ln * br}`); break;
//     case 'circle': console.log(`area of circle is ${22 / 7 * r * r}`); break;
//     case 'square': console.log(`area of square is ${s * s}`); break;
//     case 'triangle': console.log(`area of triangle is ${1 / 2 * b * h}`); break;
//     default: console.log(`Please enter valid data`); break;
// }


//while loop:
// let num = 0;
// while (num <= 10) {
//     console.log(`The number is ${num}`);
//     num++;
// }

// Do while loop
// let num = 5;
// do {
//     console.log(`the number is ${num}`); num++;
// } while (num < 10);

// Main difference between while and do-while loops is while checks the consition at start and
//do-while check condition at ending of first loop.

//For Loops:
// debugger;
// for (let i = 1; i <= 5; i++) {
//     console.log(i);
// }

// Using for loop for displaying a table of 8
// let a = 8;
// for (let x = 1; x <= 10; x++) {
//     console.log(a + '*' + x + '=' + (a * x));
// }






//===> EcmaScript : 6
// 1)let and Const          {}
// 2)Template String        {}
// 3)Destructing            {}
// 4)Rest Operator
// 5)Spread Operator
// 6)Default Arguments      {}
// 7)Arrow Function         {}
// 8)Object Property

// =>Var,  Let and Const: ES6
// var is function scoped and let/const is block scoped

//var keyword:
// function name() {
//     var fname = "Ameer";
//     console.log(fname);
//     if (true) {
//         var lname = "Hamza";
//         console.log(fname);
//         console.log(lname);
//     }
//     console.log(lname);
// }
// name();

//let Keyword:
// function name() {
//     let fname = "Ameer";
//     console.log(fname);
//     if (true) {
//         let lname = "Hamza";
//         console.log(fname);
//         console.log(lname);
//     }
//     console.log(lname);
// }
// name();

// let a = 20, b = 30;
// console.log(`The value of a is ${a} and the valu of b is ${b}`);


// =>Template Literals: ES 6
// this uses `` backticks.
// and it uses ${/*variable value*/} for variable values

// for loops using template literals.

// let tableOf = 9
// for (i = 1; i <= 10; i++) {
//     console.log(`${tableOf}*${i}=${tableOf * i}`);
// }

// the above table program from for loops is displayed using template literals.


// => Default parameters in funtion: ES 6
// let mul = function (a, b) {
//     console.log(a, b);//the value of a is passed from the argument and a=5, but value of b is passed as undefined.
//     return (a * b);
// }
// console.log(mul(5)); // returns NaN, since default parameter is passed

// let mul = function (a, b = 5) {  //here we are passing a default parameter to b.
//     console.log(a, b);
//     return (a * b);
// }
// console.log(mul(5); // so this argument is passed to a.
//if we give 2 arguments then it is passed to the function  and the default parameter is not used in this case.

// Arrow Function: ES 6
// It uses[ => ] symbol in function defination and always first define the function and then call it.

// sample of a fat arrow funtion
// Arrow function dont support /*this*/ keyword
// let sum = () => {
//     let a = 5, b = 10; return (a + b);
// }
// console.log(sum());

// Arrow function in one line with template literals:
// const sum = () => `the sum of two numbers is ${(a = 5) + (b = 10)}`;
// console.log(sum());

// const greetings = (name = 'Peter') => {
//     let message = name + ', welcome to 30 Days Of JavaScript!'
//     return message
// }
// console.log(greetings())
// console.log(greetings('John'))


// =>Destructuring : ES6
//ARRAY destructuring:
// allows you to destructure properties of an object or elements of an array into individual variables.

// function getScores() {
//     return [10, 'Hundred', 50.6];
// }
// let [x, y, z] = getScores();
// console.log(x + '\n' + y + '\n' + z)

// In this above example we are destructuring an array of 3 elements into 3 individual variables [x,y,z] in array destructureing we use [] brackets for  individual variable 

//Object Destructuring:
// const person = {
//     fname: 'Ameer',
//     lname: 'hamza'
// }
// let { fname: fName, lname: lName } = person;

// console.log(fName);
// console.log(lName);



// Excercise On Functions:

// 1)Declare a function fullName and it print out your full name.
// function fullName() {
//     return `Mohammed Ameer Hamza`;
// }
// console.log(fullName());

// 2)Declare a function fullName and now it takes firstName, lastName as a parameter and it returns your full - name.
// function name(fname, lname) {
//     return `${fname} ${lname}`;
// }
// console.log(name('Ameer', 'Hamza'));

// 3)Declare a function addNumbers and it takes two two parameters and it returns sum.
// let addNumbers = (a, b) => {
//     return `${a + b}`;
// }
// console.log(addNumbers(10, 2));

// 4)An area of a rectangle is calculated as follows: area = length x width. Write a function which calculates areaOfRectangle.
// let areaOfRectangle = (length, width) => {
//     return `${length * width}`;
// }
// console.log(areaOfRectangle(20, 30));

// 5)A perimeter of a rectangle is calculated as follows: perimeter= 2x(length + width). Write a function which calculates perimeterOfRectangle.
// const perimeterOfRectangle = (length, width) => {
//     return `${2 * (length + width)}`;
// }
// console.log(perimeterOfRectangle(2, 3));

// ==> Arrays in JavaScript
// they can store any type of elements, seperated by commas. and these elements are numbered starting from 0 to its (length -1). these are called index values
// All of the array elements are placed between [ square Brackets ]

// example of an array: 
// let names = ['john', 'mike', 'Charlie', 'jack'];
//length of the array is given by
// console.log(names.length);
//To access specific element of array:
// console.log(names[0]);//retuns the first element.
// console.log(names[1]);
// console.log(names[2]);
// console.log(names[3]);
// the last Element can be also accessed by:
// console.log(names[names.length - 1]);


// 1 Array traversal: using for loop:
// let names = ['john', 'mike', 'Charlie', 'jack'];
// for (let i = 0; i < names.length; i++) {
//     console.log(names[i]);
// }

// Using for-in and for-of loop:
// let names = ['john', 'mike', 'Charlie', 'jack'];
// for (let elements in names) {
//     console.log(elements);// for in returns the index numbers in the array.
// }

// let names = ['john', 'mike', 'Charlie', 'jack'];
// for (let elements of names) {
//     console.log(elements);// for of returns elements of the array
// }

//forEach loop: 
// let names = ['john', 'mike', 'Charlie', 'jack'];
// names.forEach(function (element, index, names) {
//     console.log(element + ` is at index` + ' ' + index + ' ' + `of the array: ` + names);
// });

// forEach using arrow function:
// let names = ['john', 'mike', 'Charlie', 'jack'];
// names.forEach((Element, index, names) => {
//     console.log(`the element ${Element} is at index ${index} of the array: ${names}`);
// });


// replacing elements in an Array:

// let names = ['john', 'mike', 'Charlie', 'jack'];
// console.log(names[2]);
// names[2] = 'nick';
// console.log(names[2]);

// ==> 2 Array searching and filter.:
// #1 indexOf() Method
// let names = ['john', 'mike', 'Charlie', 'jack'];
// console.log(names.indexOf('mike')); // here it returns the index value of 'mike' starting from the 0th posotion in forward search. And it will return -1 of none found.

// #2 lastIndexOf() method is similar to above but it starts from last and do backward search and returns the index value of that element. And it will return -1 of none found.
// let names = ['john', 'mike', 'Charlie', 'jack', 'mike'];
// console.log(names.lastIndexOf('mike'));
// console.log(names.lastIndexOf('mike', 3)); // this will start searching from third element and do backward search and returns the output 1.


// Example indexOf() and lastIndexOf() methods:
// let names = ['john', 'mike', 'Charlie', 'jack', 'mike'];
// console.log(names.indexOf('mike')); //1
// console.log(names.lastIndexOf('mike'));//4
// console.log(names.indexOf('mike', 3));//4
// console.log(names.lastIndexOf('mike', 3));//1

// #3 includes() method
// returns boolean { true or falase} after checking for the given element is present in the array or not.
// let names = ['john', 'mike', 'Charlie', 'jack', 'mike'];
// console.log(names.includes('mike')); //true
// console.log(names.includes('john', 1));// returns false as 'john' is at 0th index and the method is searching from 1 index number.

// #4 find() Method:
// it returns the element which we are searching for in the array. find() method can return only one value.
// let nums = [1, 2, 3, 4, 5, 6, 7];
// console.log(nums.find((val) => val > 6)); // 
// console.log(nums.find((val) => val > 7)); //returns undefined if not found


// #5 findIndex() Method:
// let nums = [1, 2, 3, 4, 5, 6, 7];
// console.log(nums.findIndex((val) => val > 2));// 
// console.log(nums.findIndex((val) => val > 7));returns -1 if not found

// #6 filter() Method:
// let nums = [1, 2, 3, 4, 5, 6, 7]
// let newNums = nums.filter((ele, index) => (ele > 2));
// console.log(newNums); //returns a new array with elements > 2 present in arrat nums: [3,4,5,6,7]

// // #7 sort() Method:
// sorts the given array and returns the array, it checks the first letter of each element and sort into ascending order after converting them into string
// sorting a number array does not give correct order. as it only checks the first letter of each element and sort into ascending order.
// let names = ['mike', 'john', 'Alen', 'dobby', 'Ron', 'Zake'];
// console.log(names.sort());
// let nums = [5, 3, 6, 9, 8, 2, 1, 10, 20, 30, 1000, 40003];
// console.log(nums.sort());// [1, 10, 1000, 2,20, 3, 30, 40003, 5, 6, 8,9.]



// ==> #3 CRUD Create Read Update and Delete

// #1 Push() method:
// It is used to add elements at the end of the array
// and it returns the new length of the array names
// let names = ['mike', 'john', 'Alen', 'Ron', 'Zake'];
// let count = names.push('dobby', 'zeke');
// console.log(names);// returns Array with new elements at end
// console.log(count);// returns the new length of the array names

// with numbers
// let nums = [1, 2, 5, 6, 8, 3];
// let count = nums.push(3, 5);
// console.log(nums);// returns Array with new elements at start
// console.log(count);// returns the new length of the array names


// #2 unshift() Method
// It is used to add elements at the start of the array
// and it returns the new length of the array names
// let names = ['mike', 'john', 'Alen', 'Ron', 'Zake'];
// let count = names.unshift('dobby', 'Zake');
// console.log(names);// returns Array with new elements at start
// console.log(count);// returns the new length of the array names

// with numbers
// let nums = [1, 2, 5, 6, 8, 3];
// let count = nums.unshift(3, 5);
// console.log(nums);// returns Array with new elements at start
// console.log(count);// returns the new length of the array names

// #3 POP() Method
// It is used to removes last element from the end of the array and changes the length of array
// and it returns the removed element.
// let names = ['mike', 'john', 'Alen', 'Ron', 'Zake'];
// let value = names.pop();// removes the last element from the array
// console.log(names); console.log(value);// returns the element which is removed
// console.log(names.length)// returns the length after poping

// #4 shift() Method
// It is used to removes the first element from the start of the array and changes the length of array
// and it returns the removed element.
// let names = ['mike', 'john', 'Alen', 'Ron', 'Zake'];
// let value = names.shift();// removes the last element from the array
// console.log(names); console.log(value);// returns the element which is removed
// console.log(names.length)// returns the length after poping

// ==> # Splice Method:
// This method is used to add or delete at any index of the array
//syntax:
// arrayName.splice(indexNumber,deletingValue,insertingValue);

// let names = ['mike', 'john', 'Alen', 'Ron', 'Zake'];
// let value = names.splice(2, 1, 'dobby');// this will start from given index number and removes one element on 2nd index i.e., Alen and insert 'dobby'
// console.log(names)// this will return the updated array.
// console.log(value); //his will return the removed element from the Array.

// Exercise on splice
// add element at end with splice

// let week = ['Monday', 'Tuesday', 'Wednesday', 'friday'];
// week.splice(week.length, 0, 'Sunday');//adding sunday at last;
// console.log(week);

// let week = ['Monday', 'Tuesday', 'Wednesday', 'Friday'];
// let dayIndex = week.indexOf('Friday');
// week.splice(week.length, 0, 'Sunday');//adding sunday at last;
// week.splice(dayIndex, 0, 'Thursday');// adding thursday before friday:
// console.log(week);

// Below is a program to add saturday after friday using splice method:
// let days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Sunday'];
// daysIndex = days.indexOf('Friday');
// if (daysIndex != -1) {
//     days.splice(daysIndex + 1, 0, "Saturday");
//     console.log(days);
// }
// else {
//     console.log('"Friday" is not found in the array');
// }

//delete a wednesday from array of week:
// let days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Sunday'];
// let daysIndex = days.indexOf('Wednesday');
// if (daysIndex != -1) {
//     removedDays = days.splice(daysIndex, 1);// to remove all the elements after the given index we use infinity in delete field insted of 1 or 2 or 3;
//     console.log(days);
//     console.log(removedDays);// returns the removed elements from the array;
// }
// else {
//     console.log('"Wednesday" is not found in the array');
// }

// ==>Map(), reduce() and Filter() methods

// #1 Map() Method
// It returns a new array containning  results of all elements in the array. It uses a function and calls this function for all the elements in the array. It doesn't change the original array and creates a new array to return.
// let names = ['mike', 'john', 'Alen', 'Ron', 'Zake'];
// let newArr = names.map((elem, ind, arr) => {
//     return `Element : "${elem}" is at index value : ${ind} belongs to the array: [${arr}]`
// })
// console.log(newArr);

// Exercise for Map() Method

// let arr = [1, 4, 9, 16, 25];
// let arrsqrt = arr.map((ele) => Math.sqrt(ele));// math.sqrt() Method is used to give the square root of  the elements in the given array.
// console.log(arrsqrt);

// let arr = [2, 3, 4, 6, 8,];
// let nums = arr.map((elem) => elem * 2).filter((elem => elem > 10)) // here we are chaining filter method with map method for filtering the results.
// console.log(nums);

// using reduce method to get no. of times elements are repeating.
// let name = 'Ameer Hamza';
// bebugger
// let arr = name.split(' ').join('').split('');
// let a = arr.reduce((acc, ele, index, array) => {
//     if (!acc[ele]) {
//         acc[ele] = 1;
//     }
//     else {
//         acc[ele]++;
//     }
//     return acc;
// }, {})
// console.log(a);


//==> Dates in javascript:
// Date object represents single moment in time in platform independent format.

// Dates can be created in 4 ways in JS:
// 1= new Date() //constructor
// 2= new Date(year, month, date, hours, minutes, seconds, milliseconds)
// 3= new Date(milliseconds)
// 4= new Date(date String)

// we use new Date() constructor  to create a date construcot
// let dt1 = new Date();
// console.log(dt1); //returns date and time in international form
// let dt2 = new Date().toString();
// console.log(dt2); // returns date and time in IST 
// let dt3 = new Date().toLocaleString();
// console.log(dt3); // returns date and time in local format

// //USing all the 7 parameters in Date():
// let dt = new Date(2022, 6, 15, 14, 44, 60, 0).toLocaleString(); // this will return date and time in local format:
// console.log(dt);

// Date.now() method is used to return milliseconds from 1/1/1970 to till date:
// let dt = Date.now();// returns milliseconds from 1/1/1970 to till date
// console.log(dt);

// Giving milliseconds as parameter (milliseconds)
// let dt = new Date(1657917595606);
// console.log(dt);


// Other different methods to GET different values:
// let dt = new Date();
// // console.log(dt.toString()); // returns in IST format
// // console.log(dt.getFullYear()); // REturns the Year
// console.log(dt.getMonth()); // returns 0-11 as month
// console.log(dt.getDate()); // returs todays date
// console.log(dt.getDay()); // returns todays Day

// Setting individual dates in js
// let dt = new Date(); // returns milliseconds from 1/1/1970
// console.log(dt.setDate(2022, 8, 15));// returns milliseconds from 1/1/1970
// console.log(dt.setFullYear(2025));// returns milliseconds from 1/1/1970
// console.log(dt.setMonth(08));// returns milliseconds from 1/1/1970
// console.log(dt.toString()); // REturns in IST

//Getting Time individually :
// let time = new Date();
// console.log(time.getTime());// returns milliseconds from 1/1/1970
// console.log(time.getHours());//returns hours now from 0-23 hrs
// console.log(time.getMinutes());//returns minutes
// console.log(time.getSeconds());//returns Seconds
// console.log(time.getMilliseconds());// returns Milliseconds

// Setting time individually
// let time = new Date();
// // console.log(time.setTime());
// console.log(time.setHours(2));//returns milliseconds from 1/1/1970
// console.log(time.setMinutes(3));//returns milliseconds from 1/1/1970
// console.log(time.setSeconds(4));//returns milliseconds from 1/1/1970

// Date Only and Time Only 
// let t = new Date();
// console.log(t.toLocaleTimeString());
// console.log(t.toLocaleDateString());

//==> MATHS Objects:
// It allows us to perform Mathematical tasks on numbers:

// 1) PI Math.PI Property: Uses value of PI
// console.log(Math.PI);


// 2) Math.round() Method: Gives the nearest rounded value(round figure)
// let a = 10.3456
// console.log(Math.round(a));// REturns 10

// 3)Math.pow() : Gives the exponential power. Same as (**)
// console.log(Math.pow(2, 3)); // returns 2**3 (2 raise to power of 3)

// 4) Math.sqrt(): gives the square root value of the given number.
// console.log(Math.sqrt(9)); // returns 3

// 5)Math.abs(): gives the absolute value of the given number:
// console.log(Math.abs(-55)); // returns 55

// 6)Math.ceil(): Gives the upper rounded integer of given number
// console.log(Math.ceil(10.2)); //returns 11
// console.log(Math.ceil(10));// returns 10  as already integer

// 7) Math.floor():Gives the lower rounded integer of given number:
// console.log(Math.floor(10.2)); //returns 10 as floor value
// console.log(Math.floor(10));// returns 10  as already integer

// 8) Math.min(): gives the lowest value in the list of arguments:
// console.log(Math.min(100, 3000, 2, -5, 0, -222)); //returns -222,

// 9) Math.max(): gives the highest value in the list of arguments:
// console.log(Math.max(100, 3000, 2, -5, 0, -222)); //returns 3000

//10) Math.random(); always gives random number between 0 and 1 inclusive 0.
// console.log(Math.random());// returns any random number between 0 and 1.
// console.log(Math.floor(Math.random() * 10)); // this will return values from 0 to 9 (0,9 both inclusive)

// 11)Math.trunc(): It gives the interger part of the given number (it can be positive or negative)
// console.log(Math.trunc(4.9)); // returns 4
// console.log(Math.trunc(-4.9));//returns -4


// Practice:
// let a = Math.trunc(4.5);// equal to Math.floor()
// let b = Math.floor(4.5);// equal to Math.trunc()
// let c = Math.trunc(-4.5);//equal to Math.ceil()
// let d = Math.ceil(-4.5);//equal to Math.trunc()
// if (a == b && c == d) {
//     console.log(true);
// }
// else {
//     console.log(false);
// }



// // Starting 20 numbers which are divisible by 7 and return 1 if divided by 2:
// let arr = [];
// for (let i = 1; arr.length < 20; i++) {
//     if (i % 7 == 0 && i % 2 == 1) {
//         arr.push(i)
//     }
// }
// console.log(arr);
// arr.forEach((ele) => console.log(ele));
// // console.log(arr.length);



// DOM : Document Object Model

// The Document Object Model(DOM) is a programming interface for web documents.It represents the page so that programs can change the document 
// structure, style, and content.The DOM represents the document as nodes and objects; that way, programming languages can interact with the page.
// Window is the main container or we can say the global Object.
// And the DOM is the child of Window Object.

// Since window is the global object    
// so you do not have to write down window It will be figured out by the runtime.
// window.location and location both gives the current URL.

// But in case of DOM if we want to use the document object, methods or properties:
// document.getElementById() Should always use Document 

// Window has methods, properties and object. 
// ex setTimeout() or setInterval() are the methods 
// where as Document is the object of the Window and 
// It also has a screen object with properties 
// describing the physical display.


// The DOM is the Document Object Model, which deals with the document, 
// the HTML elements themselves, e.g. document and all traversal you 
// would do in it, events, etc.
//Example
// change the background color to red
// document.body.style.background = "red";

// DOM practicle example  in HTML

//refer file DOM manipulation for Events in JavaScript:

// Events in JavaScript:
// Event can be anything that browser does,or happens to browser, or user does

// Examples of HTML events:
/* Browser completes it loading
An input feild has changed
Button is clicked

JS lets us exucute codes when events are detected
*/

// We can use HTML event handlers with JS to handle events and perform tasks with events

/*we can write events in JS in following ways:
1) Using alert(); //simple inline
2) By calling a function (one of the most common way of writing events) //calling function
3) By using inline events (HTML onclick="" propertty and element.onclick)
4) By using event listners ( addEventListner and IE's attachEvent)
*/

// => Object Event is parent of all the event objects
// example: Mouse Events, Keyboard Events, input Events ...
//  we can check details of the event using :
//  event, event.target, event.type etc...

// => Mouse Events;
// Events related to mouse are mouse events, it occurs when mouse interacts with html
// few mouse events are as follows:
// onmousedown(), onmouseup(), onmouseente(), onmouseleave() etc...

// => KeyBoard events:
// Events related to keyboard interaction, it occurs when user presses keys on the keyboard
// few KeyBoard events are as follows:
// onkeypress(), onkeyup(), onkeydown() etc...

// input Events:
// It is related to any input in the html.
// onchange event is an example of input event


// InlineEvent (Onclick) vs  addEventListener
// the addEventListener does not override existing event handler whereas the onclick overrides any exiting event handler = function event handlers
//another significant diffeerence is:
//onclick will always work  whereas addEventListener does not work in Internet Explorer before version 9;

//Refer DOM_Manipulation.HTML File for code Examples

//JS timing Events:
// Window Object allows execution of codes at specified time  intervals,
// these time intervals are called as timeing Events:
// There are 2 key methods.

// setTimeout(function, milliseconds)
// It executes the function after waiting for the specified number of milliseconds

// setInterval(function, milliseconds)
// IT executes the function similar to setTimeOut() but repeats the execution contineously.

// There are 4 methods in timing Events
// 1) setTimeOut()
// 2)setInterval()
// 3)clearTimeOut()
// 4)clearInterval()

// Refer the DOM_Manipulation.HTML file for practicle example




// Object oriented JavaScript:
// Object literal is simply key:Value pair data structure
// objects can store different types of variable and functions in one container

// creating an object:

// 1st way:

// let bioData = {
//     name: 'Ameer',
//     age: 22,
//     location: 'Hyderabad',
//     getData: function () {
//         console.log(`my name is ${bioData.name} and my age is ${bioData.age} and I live in ${this.location}`);
//     }
// }
// console.log(bioData.name)
// bioData.getData();

//2nd Way:
// Its not required to write function keyword in the function in objects:

// let bioData = {
//     name: 'Ameer',
//     age: 22,
//     location: 'Hyderabad',
//     getData() {
//         console.log(`my name is ${bioData.name} and my age is ${bioData.age} and I live in ${this.location}`);
//     }
// }
// console.log(bioData.name)
// bioData.getData();

// 3rd way:
// object in an object:
// let biodata = {
//     name: {
//         fName: 'Ameer',
//         lName: 'Hamza'
//     },
//     age: 25,
//     location: 'Hyderabad',
//     getData() {
//         console.log(`my name is ${this.name} and my age is ${this.age} and I live in ${this.location}`);
//     }
// }
// biodata.getData();
// console.log(biodata['name']['lName']);// we can access the values using [] brackets,
// console.log(biodata.name.fName);// we can also get the values using .



// This keyword in objects:
// this keyword specifies the current Context, at start it refers the window i.e., global object.
// this is used in the above example:

// examples of 'this':
// 1)
// console.log(this); // run this in browser, will return the window object.

// 2)
// function name(){
//     console.log(this);
// }
// name(); //  when we run this in browser console, it will still return the window onject;

//3)
// var myname='ameer'
// function name(){
//     console.log(this.myname);
// }
// name();// now when we run this in browser console, it will return the value of myname, since myname is global scoped and this refers window object

//4)
// const obj = {
//     age: 22,
//     name() {
//         console.log(this.age);
//     }
// }
// obj.name(); // when we run this in browser console, it will return the value of age from the function, here the this refers to the current object.

// 5)
// this object will not work with arrow function:

// const obj = {
//     age: 22,
//     name: () => {
//         console.log(this);
//     }
// }
// obj.name();  // when we run this in browser console, it will return the {}, we cant use this in arrow functions


// in oop '"object is an instance of class"', objects have methods and properties.

// object
// properties                                       // methods
// attributes OR states                             // Does something 
// function & procedure


// class is a  user defined blueprint or protype from which objects are created. We use keyword 'class' to initiate it:]
// syntax:
// class class-name{
//methods and properties
// }


// example of a class
// class MyFunc {
//     constructor(name, age, locat) {
//         this.myName = name;
//         this.myAge = age;
//         this.myLocat = locat;
//     }
//     discrip() {
//         console.log(`Hi, my name is ${this.myName} and i am ${this.myAge} years old, I live in ${this.locat}`);

//     }
// }
// let obj1 = new MyFunc('Ameer', 22, 'HYD');
// let obj2 = new MyFunc('Hamza', 22, 'HYD');
// obj1.discrip();
// obj2.discrip();



// Inheriting from another class
// class MyFunc {
//     constructor(name, age, locat) {
//         this.myName = name;
//         this.myAge = age;
//         this.myLocat = locat;
//     }
//     discrip() {
//         console.log(`Hi, my name is ${this.myName} and i am ${this.myAge} years old, I live in ${this.locat}`);

//     }
// }
// class Player extends MyFunc {
//     constructor(name, age, locat, game) {
//         super(name, age, locat); //super keyword is used here to inherit the properties from parent class.
//         this.myGame = game;
//     }
//     discrip() {
//         console.log(`Hi, my name is ${this.myName} and i am ${this.myAge} years old, I live in ${this.locat}, and I play ${this.myGame}`);

//     }

// }
// let obj1 = new Player('Ameer', 22, 'HYD', 'Soccer');
// obj1.discrip();
