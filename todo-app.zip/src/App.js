//import logo from './logo.svg';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./App.css";
import React, { useState } from "react";
import Categories from "./components/Categories";
import CategoryList from "./components/CategoryList";
import { useSelector, useDispatch } from "react-redux";
import { addCategory, updateCategory } from "./store/categoriesSlice";
import { Container, Row, Col } from "react-bootstrap";

function App() {
  const categories = useSelector((state) => state.categories.value);
  const [selectedCategory, setSelectedCategory] = useState(undefined);
  const dispatch = useDispatch();

  const categoryNames = categories.map((category) => category.name);

  const handleAddCategory = (name) => {
    console.log("name", name);
    const index = categories.findIndex((category) => category.name === name);
    if (index === -1) {
      dispatch(addCategory({ name: name, items: [] }));
      return true;
    }
    return false;
  };

  const selectCategory = (index) => {
    setSelectedCategory(categories[index]);
    console.log("selectedCategory", selectedCategory);
  };

  const handleAddItem = (name) => {
    if (selectedCategory) {
      const index = selectedCategory.items.findIndex(
        (item) => item.name === name
      );
      if (index === -1) {
        const updatedCategory = {
          name: selectedCategory.name,
          items: [...selectedCategory.items, { name: name, completed: false }],
        };
        dispatch(updateCategory({ category: updatedCategory }));

        console.log(updatedCategory, "updatedCategory");
        setSelectedCategory(updatedCategory);
        return true;
      }
      return false;
    }
  };

  const handleToggleItem = (index) => {
    if (selectedCategory) {
      const updatedItems = selectedCategory.items.map((item, i) => {
        if (index === i) {
          return {
            ...item,
            completed: !item.completed,
          };
        } else {
          return item;
        }
      });

      const updatedCategory = {
        name: selectedCategory.name,
        items: updatedItems,
      };
      dispatch(updateCategory({ category: updatedCategory }));
      setSelectedCategory(updatedCategory);
    }
  };

  const handleDeleteItem = (index) => {
    if (selectedCategory) {
      const updatedItems = selectedCategory.items.filter((item, i) => {
        return index !== i;
      });

      const updatedCategory = {
        name: selectedCategory.name,
        items: updatedItems,
      };
      dispatch(updateCategory({ category: updatedCategory }));
      setSelectedCategory(updatedCategory);
    }
  };

  console.log("categories App", categories);

  return (
    <Container fluid>
      <Row>
        <Col sm={2}>
          <Categories
            categories={categoryNames}
            addCategory={handleAddCategory}
            selectCategory={selectCategory}
          />
        </Col>
        <Col sm={8}>
          <CategoryList
            category={selectedCategory}
            toggleItem={handleToggleItem}
            addItem={handleAddItem}
            deleteItem={handleDeleteItem}
          />
        </Col>
      </Row>
    </Container>
  );
}

export default App;
