import { createSlice } from "@reduxjs/toolkit";

export const categoriesSlice = createSlice({
  name: "categories",
  initialState: {
    value: [],
  },
  reducers: {
    addCategory: (state, action) => {
      console.log("payload", action.payload);
      state.value.push(action.payload);
      console.log("state", state);
    },
    updateCategory: (state, action) => {
      console.log("addItemToCategory", action.payload);
      const category = state.value.find(
        (category) => category.name === action.payload.category.name
      );
      console.log("category", category);
      category.name = action.payload.category.name;
      category.items = action.payload.category.items;
      console.log("category", category);
      console.log("state", state);
    },
    removeCategory: (state, action) => {
      state.value.splice(action.payload, 1);
    },
  },
});

// Action creators are generated for each case reducer function
export const { addCategory, updateCategory, removeCategory } =
  categoriesSlice.actions;

export default categoriesSlice.reducer;
