import React, { Fragment, useState } from "react";
import { Button, Modal, Form, ListGroup } from "react-bootstrap";
import { Stack, Row, Col } from "react-bootstrap";

const CategoryList = (props) => {
  const { category } = props;
  console.log("selected category", category);
  const [show, setShow] = useState(false);
  const itemRef = React.createRef();

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const handleAdd = () => {
    const item = itemRef.current.value;
    if (item && item.length > 0) {
      props.addItem(item);
      handleClose();
    }
  };

  const handleClick = (event) => {
    console.log(event.target);
    const index = parseInt(event.target.id);
    props.toggleItem(index);
  };

  if (!category) {
    return <Fragment />;
  }

  const items = category.items.map((item, index) => (
    <Row>
    <Stack direction="horizontal" gap={6}>

      <Form.Check
        className={
          item.completed ? "item-completed checkbox-item" : "checkbox-item"
        }
        type="checkbox"
        onClick={handleClick}
        key={index}
        id={index}
        label={item.name}
      />
      <Button
        variant="danger"
        className="ms-auto"
        size="sm"
        id={index}
        onClick={() => props.deleteItem(index)}
      >
        Delete
      </Button>

    </Stack>
    </Row>
  ));

  return (
    <Fragment>
      <h2 className="text-center">{category.name}</h2>
      <Row className="justify-content-md-center">
        <Col className="text-end">
          <Button variant="primary" onClick={handleShow}>
            Add Item
          </Button>
        </Col>
      </Row>
      {items}

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Add Item</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form.Label htmlFor="item">Item</Form.Label>
          <Form.Control type="text" id="item" ref={itemRef} />
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleAdd}>
            Add
          </Button>
        </Modal.Footer>
      </Modal>
    </Fragment>
  );
};

export default CategoryList;
