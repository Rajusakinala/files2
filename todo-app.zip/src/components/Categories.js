import React, { useState } from "react";
import { Button, Modal, Form, ListGroup } from "react-bootstrap";

const Categories = (props) => {
  const [show, setShow] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState(-1);
  const categoryRef = React.createRef();

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const handleAdd = () => {
    const category = categoryRef.current.value;
    if (category && category.length > 0) {
      props.addCategory(category);
      handleClose();
    }
  };

  const handleClick = (event) => {
    console.log(event.target);
    const index = parseInt(event.target.id);
    props.selectCategory(index);
    setSelectedCategory(index);
    //() => props.selectCategory(index)
  };

  const getCategoriesList = () => {
    const list = props.categories.map((category, index) => {
      return (
        <ListGroup.Item className={(selectedCategory === index) ? "active" : ""} key={index} id={index} onClick={handleClick}>{category}</ListGroup.Item>
      );
    });

    return (<ListGroup>{list}</ListGroup>);
  }
  

  return (
    <>
      <h2 className="text-center">Categories</h2>

      {getCategoriesList()}

      <Button className="add-category" variant="primary" onClick={handleShow}>
        Add Category
      </Button>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Add Category</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form.Label htmlFor="category">Category</Form.Label>
          <Form.Control type="text" id="category" ref={categoryRef} />
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleAdd}>
            Add
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default Categories;
